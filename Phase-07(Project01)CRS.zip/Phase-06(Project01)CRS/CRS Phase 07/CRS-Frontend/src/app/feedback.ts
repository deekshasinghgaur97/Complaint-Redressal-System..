export class Feedback {
    fid!: number;
    cid!: number;
    username!: string;
    complaint!: string;
    feedback!: string;
}