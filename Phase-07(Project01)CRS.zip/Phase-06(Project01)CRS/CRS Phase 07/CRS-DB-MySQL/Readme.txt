Step 1- Open the MySQL Database.
Step 2- Click on Server -> import data -> Import from self-contained file.
Step 3- Select the dump file to import and click start import.